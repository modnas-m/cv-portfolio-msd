<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { usePortfolio } from '../stores/portfolio.js'
import VoxelScene from '../components/VoxelScene.vue'
import LayerList from '../components/LayerList.vue'
import PixelIcon from '../components/PixelIcon.vue'
import Compass from '../components/Compass.vue'
import WeatherSky from '../components/WeatherSky.vue'
import { Aggregator } from '../three/aggregate.js'
import { getWeather, KINDS } from '../weather.js'
import { useTheme } from '../stores/theme.js'

const p = usePortfolio()
const theme = useTheme()
const weather = ref(null)
const weatherLine = computed(() => {
  const wx = weather.value
  if (!wx) return ''
  const temp = wx.temp == null ? '' : `, ${wx.temp} °C`
  return `${wx.place} right now: ${KINDS[wx.kind].label}${temp}`
})
const stageEl = ref(null)
const scene = ref(null)
const progress = ref(0)
const wide = ref(true)
const turns = ref(0)

// keep the cluster in the space the text and the layer list leave free
const safe = computed(() => wide.value
  ? { left: 400, right: 300, top: 64, bottom: 88 }
  : { left: 0, right: 0, top: 200, bottom: 150 })

// Scrolling through the first section takes the cluster apart.
const explode = computed(() => Math.min(1, progress.value / 0.8))
const card = computed(() => p.selected && p.projectFor(p.selected))

// The cluster: a new seed on every visit, or ?seed=12345 to get one back.
const seed = ref(0)
const modules = ref(0)
const grown = ref(false)
let agg = null
let timer = null

function newSeed() {
  const fromUrl = Number(new URLSearchParams(location.search).get('seed'))
  return fromUrl > 0 && !seed.value ? fromUrl : 10000 + Math.floor(Math.random() * 89999)
}

function grow() {
  clearInterval(timer)
  seed.value = newSeed()
  agg = new Aggregator(seed.value)
  modules.value = 0
  grown.value = false
  scene.value?.reset()
  timer = setInterval(() => {
    if (document.hidden) return
    const parts = agg.step()
    if (!parts) { grown.value = true; clearInterval(timer); return }
    scene.value?.add(parts)
    modules.value = agg.roomCount
  }, 520)
}

function onResize() {
  wide.value = window.innerWidth >= 900
  onScroll()
}

function onScroll() {
  const el = stageEl.value
  if (!el) return
  const r = el.getBoundingClientRect()
  const travel = el.offsetHeight - window.innerHeight
  progress.value = travel > 0 ? Math.min(1, Math.max(0, -r.top / travel)) : 1
}

// choosing a layer highlights it; only scrolling takes the cluster apart
function choose(id) {
  p.selected = p.selected === id ? null : id
}

function onKey(e) {
  if (e.key === 'Escape') p.selected = null
}

onMounted(() => {
  getWeather().then((wx) => (weather.value = wx))
  window.addEventListener('scroll', onScroll, { passive: true })
  window.addEventListener('resize', onResize)
  window.addEventListener('keydown', onKey)
  onResize()
})
onBeforeUnmount(() => {
  clearInterval(timer)
  window.removeEventListener('scroll', onScroll)
  window.removeEventListener('resize', onResize)
  window.removeEventListener('keydown', onKey)
})
</script>

<template>
  <main>
    <section ref="stageEl" class="stage" aria-label="The cluster">
      <div class="sticky">
        <WeatherSky :kind="weather?.kind || 'clear'" :dark="theme.dark" :safe="safe" />
        <VoxelScene
          ref="scene"
          class="scene"
          :explode="explode"
          :selected="p.selected"
          :hovered="p.hovered"
          :safe="safe"
          :dark="theme.dark"
          @hover="(id) => (p.hovered = id)"
          @select="choose"
          @turn="(n) => (turns = n)"
          @ready="grow"
        />

        <div class="intro" :class="{ away: card }" :aria-hidden="!!card">
          <h1>{{ p.site.tagline }}</h1>
          <p class="role">{{ p.site.role }} in Barcelona. Every layer of this cluster is something I worked on.</p>
          <p class="hint" :class="{ gone: explode > 0.08 }">Scroll to take it apart.</p>
        </div>

        <LayerList class="list" @choose="choose" />

        <aside v-if="card" class="card" aria-live="polite">
          <button class="close pixel-button" type="button" aria-label="Close" @click="p.selected = null">
            <PixelIcon name="close" />
          </button>
          <p class="card-layer">{{ p.layerName(p.selected) }}</p>
          <p class="card-shows">{{ p.layerShows(p.selected) }}</p>
          <h2>{{ card.title }}</h2>
          <p class="card-line">{{ card.oneLiner }}</p>
          <RouterLink class="pixel-button open" :to="`/work/${card.slug}`">Open project</RouterLink>
        </aside>

        <div class="controls">
          <div class="grower">
            <p class="building-name">
              <span class="b-title">Specimen {{ seed }}</span>
              <span class="b-meta">{{ modules }} rooms, {{ grown ? 'fully grown' : 'still growing' }}</span>
            </p>
            <button class="pixel-button" type="button" @click="grow">Grow another</button>
          </div>
          <div class="turn">
            <p v-if="weatherLine" class="weather-line">{{ weatherLine }}</p>
            <p class="drag-hint">Drag the model to turn it</p>
            <button class="pixel-button compass" type="button" aria-label="Turn the model a quarter turn" @click="scene?.rotate(1)">
              <Compass :turns="turns" />
            </button>
          </div>
        </div>
      </div>
    </section>

    <section class="what" aria-labelledby="what-title">
      <h2 id="what-title">What I do</h2>
      <ul>
        <li v-for="line in p.site.whatIDo" :key="line">{{ line }}</li>
      </ul>
      <p class="more">
        <RouterLink to="/cv">Read the CV</RouterLink> or
        <a :href="`mailto:${p.site.email}`">write to me</a>.
      </p>
    </section>
  </main>
</template>

<style scoped>
.stage { height: 280vh; position: relative; }
.sticky { position: sticky; top: 0; height: 100vh; height: 100svh; overflow: hidden; }
.scene { position: absolute; inset: 0; }

.intro { position: absolute; left: var(--gutter); top: 88px; max-width: 30ch; pointer-events: none; transition: opacity .25s; }
.intro.away { opacity: 0; }
h1 { font-size: clamp(32px, 4.4vw, 56px); }
.role { margin-top: 16px; max-width: 34ch; background: var(--paper); }
.hint { margin-top: 24px; font-family: var(--font-pixel); font-size: 18px; color: var(--signal); transition: opacity .4s; }
.hint.gone { opacity: 0; }

.list { position: absolute; right: var(--gutter); top: 50%; transform: translateY(-50%); }

.card {
  position: absolute; left: var(--gutter); top: 96px;
  width: 360px; padding: 20px 20px 24px; background: var(--paper);
  border: 2px solid var(--ink); box-shadow: 6px 6px 0 var(--signal);
}
.card-layer { font-family: var(--font-pixel); font-size: 16px; color: var(--signal); }
.card-shows { font-size: var(--t-small); color: var(--stone); margin: 2px 40px 12px 0; }
.card h2 { font-size: 28px; margin-top: 4px; }
.card-line { margin: 12px 0 20px; }
.open { text-decoration: none; }
.close { position: absolute; top: 12px; right: 12px; min-width: 32px; height: 32px; padding: 0; box-shadow: 2px 2px 0 var(--ink); }

.controls {
  position: absolute; left: var(--gutter); right: var(--gutter); bottom: 24px;
  display: flex; justify-content: space-between; align-items: end; gap: 16px; pointer-events: none;
}
.controls > * { pointer-events: auto; }
.grower, .turn { display: flex; align-items: center; gap: 12px; }
.building-name { display: grid; background: var(--paper); padding: 0 4px; min-width: 0; }
.b-title { font-family: var(--font-pixel); font-size: 20px; line-height: 1.1; }
.b-meta { font-size: var(--t-small); color: var(--stone); }
.weather-line, .drag-hint { font-size: var(--t-small); color: var(--stone); background: var(--paper); padding: 0 4px; }
.weather-line { margin-right: 16px; }
.compass { width: 44px; height: 44px; padding: 0; }

.what { padding: 120px var(--gutter) 140px; max-width: 1200px; margin: 0 auto; }
.what h2 { font-size: var(--t-h2); }
.what ul { list-style: none; padding: 0; margin: 32px 0 0; display: grid; gap: 4px; }
.what li { font-size: clamp(22px, 3vw, 36px); line-height: 1.25; max-width: 30ch; padding: 12px 0; border-top: 2px solid var(--ink); }
.what li:hover { color: var(--signal); }
.more { margin-top: 40px; font-size: var(--t-lead); }

@media (max-width: 899px) {
  .intro { top: 72px; right: var(--gutter); max-width: none; }
  h1 { font-size: 30px; }
  .role { font-size: 15px; margin-top: 10px; }
  .hint { margin-top: 12px; font-size: 16px; }
  .list { top: auto; bottom: 84px; left: var(--gutter); right: var(--gutter); transform: none; }
  .card { left: var(--gutter); right: var(--gutter); top: 72px; width: auto; }
  .controls { bottom: 16px; align-items: center; }
  .grower { gap: 10px; }
  .b-title { font-size: 15px; white-space: nowrap; }
  .b-meta, .weather-line, .drag-hint { display: none; }
  .grower .pixel-button { white-space: nowrap; font-size: 14px; }
  .turn { gap: 8px; }
}
</style>
